package com.openai.pharmacoach.data

import android.content.Context
import android.net.Uri
import kotlinx.serialization.json.Json
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

class CourseRepository(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true }
    private val modelRoot: File = File(context.filesDir, "model")
    private val currentDir: File = File(modelRoot, "current")
    private val tempDir: File = File(modelRoot, "_incoming")

    data class ModelInfo(
        val installed: Boolean,
        val version: String = "نصب نشده",
        val sizeBytes: Long = 0L,
        val source: String = "-",
        val manifestText: String = ""
    )

    data class InstallResult(
        val ok: Boolean,
        val message: String,
        val info: ModelInfo = ModelInfo(false)
    )

    fun modelInfo(): ModelInfo {
        val course = File(currentDir, COURSE_FILE)
        val model = File(currentDir, MODEL_FILE)
        if (!course.exists() || !model.exists()) return ModelInfo(false)
        val manifest = File(currentDir, MANIFEST_FILE).takeIf { it.exists() }?.readText(Charsets.UTF_8).orEmpty()
        val version = Regex("\"version\"\\s*:\\s*\"([^\"]+)\"").find(manifest)?.groupValues?.getOrNull(1)
            ?: Regex("\"modelVersion\"\\s*:\\s*\"([^\"]+)\"").find(model.readText(Charsets.UTF_8).take(4000))?.groupValues?.getOrNull(1)
            ?: "مدل نصب‌شده"
        val size = currentDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
        return ModelInfo(true, version, size, currentDir.absolutePath, manifest)
    }

    fun loadCourseOrNull(): Course? {
        val file = File(currentDir, COURSE_FILE)
        if (!file.exists()) return null
        return runCatching { json.decodeFromString(Course.serializer(), file.readText(Charsets.UTF_8)) }.getOrNull()
    }

    fun loadAiModelTextOrNull(): String? {
        val file = File(currentDir, MODEL_FILE)
        if (!file.exists()) return null
        return file.readText(Charsets.UTF_8)
    }

    fun installModelFromUri(uri: Uri): InstallResult = runCatching {
        context.contentResolver.openInputStream(uri)?.use { input ->
            tempDir.deleteRecursively()
            tempDir.mkdirs()
            val zipFile = File(tempDir, "incoming_model.zip")
            FileOutputStream(zipFile).use { output -> input.copyTo(output) }
            installFromZipFile(zipFile, "فایل انتخاب‌شده از گوشی")
        } ?: InstallResult(false, "فایل مدل باز نشد. دوباره zip مدل را انتخاب کن.")
    }.getOrElse { InstallResult(false, "نصب مدل ناموفق بود: ${it.message ?: it::class.java.simpleName}") }

    fun downloadAndInstallModel(url: String): InstallResult = runCatching {
        tempDir.deleteRecursively()
        tempDir.mkdirs()
        val zipFile = File(tempDir, "downloaded_model.zip")
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20000
            readTimeout = 60000
            requestMethod = "GET"
            instanceFollowRedirects = true
        }
        conn.inputStream.use { input -> FileOutputStream(zipFile).use { output -> input.copyTo(output) } }
        installFromZipFile(zipFile, "دانلود از GitHub")
    }.getOrElse { InstallResult(false, "دانلود/نصب مدل ناموفق بود: ${it.message ?: it::class.java.simpleName}") }

    fun resetModel(): InstallResult {
        currentDir.deleteRecursively()
        return InstallResult(true, "مدل حذف شد. برای استفاده دوباره، zip مدل را نصب کن.", modelInfo())
    }

    private fun installFromZipFile(zipFile: File, source: String): InstallResult {
        if (!zipFile.exists() || zipFile.length() < 128) {
            return InstallResult(false, "zip مدل معتبر نیست یا بسیار کوچک است.")
        }
        val extractDir = File(tempDir, "extracted")
        extractDir.deleteRecursively()
        extractDir.mkdirs()

        val wanted = linkedMapOf(
            COURSE_FILE to false,
            MODEL_FILE to false,
            MANIFEST_FILE to false
        )

        ZipInputStream(FileInputStream(zipFile).buffered()).use { zis ->
            while (true) {
                val entry = zis.nextEntry ?: break
                if (entry.isDirectory) continue
                val safeName = entry.name.substringAfterLast('/').substringAfterLast('\\')
                if (safeName in wanted.keys) {
                    val outFile = File(extractDir, safeName)
                    val canonicalRoot = extractDir.canonicalPath + File.separator
                    val canonicalOut = outFile.canonicalPath
                    if (!canonicalOut.startsWith(canonicalRoot)) {
                        return InstallResult(false, "zip مدل ناامن است و مسیر غیرمجاز دارد.")
                    }
                    FileOutputStream(outFile).use { output -> zis.copyTo(output) }
                    wanted[safeName] = true
                }
                zis.closeEntry()
            }
        }

        val missingRequired = listOf(COURSE_FILE, MODEL_FILE).filter { wanted[it] != true }
        if (missingRequired.isNotEmpty()) {
            return InstallResult(false, "داخل zip مدل این فایل‌ها پیدا نشد: ${missingRequired.joinToString()} . zip مدل باید فقط یک مدل کامل داشته باشد.")
        }

        val courseText = File(extractDir, COURSE_FILE).readText(Charsets.UTF_8)
        val modelText = File(extractDir, MODEL_FILE).readText(Charsets.UTF_8)
        val parsed = runCatching { json.decodeFromString(Course.serializer(), courseText) }.getOrNull()
        if (parsed == null || parsed.chapters.isEmpty()) {
            return InstallResult(false, "فایل درس داخل مدل خراب است یا فصل ندارد.")
        }
        if (modelText.length < 200) {
            return InstallResult(false, "فایل مدل بسیار کوچک یا ناقص است.")
        }

        currentDir.deleteRecursively()
        currentDir.mkdirs()
        File(extractDir, COURSE_FILE).copyTo(File(currentDir, COURSE_FILE), overwrite = true)
        File(extractDir, MODEL_FILE).copyTo(File(currentDir, MODEL_FILE), overwrite = true)
        val manifestFile = File(extractDir, MANIFEST_FILE)
        if (manifestFile.exists()) {
            manifestFile.copyTo(File(currentDir, MANIFEST_FILE), overwrite = true)
        } else {
            File(currentDir, MANIFEST_FILE).writeText("{\"version\":\"runtime-external\",\"source\":\"$source\"}", Charsets.UTF_8)
        }
        File(currentDir, "installed_from.txt").writeText(source, Charsets.UTF_8)
        tempDir.deleteRecursively()
        return InstallResult(true, "مدل با موفقیت نصب شد؛ ${parsed.chapters.size} فصل فعال شد.", modelInfo())
    }

    companion object {
        const val COURSE_FILE = "pharma_course_fa.json"
        const val MODEL_FILE = "pharma_runtime_model_v12.json"
        const val MANIFEST_FILE = "pharma_runtime_manifest_v12.json"
        const val DEFAULT_MODEL_URL = "https://github.com/arvinneowave78-dev/PharmaCoachAI/releases/latest/download/pharmacoach_model_v13.zip"
    }
}
