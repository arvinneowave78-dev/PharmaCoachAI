package com.openai.pharmacoach.ui

import android.content.Intent
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.openai.pharmacoach.PharmaViewModel
import com.openai.pharmacoach.ui.screens.AnalyticsScreen
import com.openai.pharmacoach.ui.screens.ChapterScreen
import com.openai.pharmacoach.ui.screens.ChaptersScreen
import com.openai.pharmacoach.ui.screens.HomeScreen
import com.openai.pharmacoach.ui.screens.ModelSetupScreen
import com.openai.pharmacoach.ui.screens.QuizScreen

@Composable
fun PharmaApp(viewModel: PharmaViewModel) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val context = LocalContext.current

    Scaffold(
        bottomBar = {
            NavigationBar {
                listOf(
                    Triple("model", "مدل", Icons.Default.Storage),
                    Triple("home", "خانه", Icons.Default.Home),
                    Triple("chapters", "درس‌ها", Icons.Default.Book),
                    Triple("quiz", "آزمون", Icons.Default.Psychology),
                    Triple("analytics", "تحلیل", Icons.Default.Analytics),
                ).forEach { (r, label, icon) ->
                    NavigationBarItem(
                        selected = route == r,
                        onClick = { nav.navigate(r) { launchSingleTop = true } },
                        label = { Text(label) },
                        icon = { Icon(icon, contentDescription = label) }
                    )
                }
            }
        }
    ) { _ ->
        NavHost(navController = nav, startDestination = "model") {
            composable("model") { ModelSetupScreen(viewModel, onModelReady = { nav.navigate("home") { launchSingleTop = true } }) }
            composable("home") { HomeScreen(viewModel, onOpenChapter = { id -> viewModel.openChapter(id); nav.navigate("chapter") }, onStartDiagnostic = { viewModel.startAdaptiveChallenge(); nav.navigate("quiz") }, onInstallModel = { nav.navigate("model") }) }
            composable("chapters") { ChaptersScreen(viewModel, onOpen = { id -> viewModel.openChapter(id); nav.navigate("chapter") }, onInstallModel = { nav.navigate("model") }) }
            composable("chapter") { ChapterScreen(viewModel, onStartQuiz = { id -> viewModel.startQuiz(id); nav.navigate("quiz") }, onShareMindMap = { viewModel.shareCurrentChapterMindMap { context.startActivity(Intent.createChooser(it, "اشتراک مایندمپ")) } }) }
            composable("quiz") { QuizScreen(viewModel) }
            composable("analytics") { AnalyticsScreen(
                viewModel,
                onShareEducatorReport = { viewModel.shareEducatorGraphic { context.startActivity(Intent.createChooser(it, "اشتراک گزارش مدرس")) } },
                onExportEncrypted = { viewModel.exportEncryptedDeveloperFile { } },
                onShareSavedNotesPdf = { viewModel.shareSavedNotesPdf { context.startActivity(Intent.createChooser(it, "اشتراک PDF نکات")) } }
            ) }
        }
    }
}
