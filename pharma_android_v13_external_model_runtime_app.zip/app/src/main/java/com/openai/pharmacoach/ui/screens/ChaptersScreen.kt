package com.openai.pharmacoach.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.openai.pharmacoach.PharmaViewModel

@Composable
fun ChaptersScreen(viewModel: PharmaViewModel, onOpen: (String) -> Unit, onInstallModel: () -> Unit) {
    val course = viewModel.course
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("مسیر یادگیری", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black) }
        if (course == null) {
            item {
                ElevatedCard(shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("مدل نصب نیست", fontWeight = FontWeight.Black)
                        Text("فصل‌ها از داخل مدل خارجی خوانده می‌شوند. اول zip مدل را نصب کن.")
                        Button(onClick = onInstallModel, modifier = Modifier.fillMaxWidth()) { Text("نصب مدل") }
                    }
                }
            }
            return@LazyColumn
        }
        items(course.chapters) { ch ->
            OutlinedCard(Modifier.fillMaxWidth().clickable { onOpen(ch.id) }, shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(ch.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(ch.subtitle)
                    Spacer(Modifier.height(8.dp))
                    Text("بخش‌ها: ${ch.sections.size} | رمزها: ${ch.mnemonics.size} | تست‌ها: ${ch.questions.size}")
                }
            }
        }
    }
}
