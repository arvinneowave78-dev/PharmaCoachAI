package com.openai.pharmacoach.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Light = lightColorScheme(
    primary = Color(0xFF047857),
    secondary = Color(0xFF0284C7),
    tertiary = Color(0xFF0F766E),
    background = Color(0xFFF7FBFF),
    surface = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFD1FAE5),
    secondaryContainer = Color(0xFFE0F2FE),
    tertiaryContainer = Color(0xFFCCFBF1),
    errorContainer = Color(0xFFFEE2E2)
)

private val Dark = darkColorScheme(
    primary = Color(0xFF34D399),
    secondary = Color(0xFF38BDF8),
    tertiary = Color(0xFF5EEAD4),
    background = Color(0xFF020617),
    surface = Color(0xFF0F172A),
    primaryContainer = Color(0xFF064E3B),
    secondaryContainer = Color(0xFF075985)
)

@Composable
fun PharmaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
}
