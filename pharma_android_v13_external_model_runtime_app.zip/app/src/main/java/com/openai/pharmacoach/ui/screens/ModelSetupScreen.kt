package com.openai.pharmacoach.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.openai.pharmacoach.PharmaViewModel

@Composable
fun ModelSetupScreen(viewModel: PharmaViewModel, onModelReady: () -> Unit) {
    val modelPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri: Uri? -> uri?.let { viewModel.installModelZip(it) } }
    )

    val info = viewModel.modelInfo
    val gradient = Brush.linearGradient(
        listOf(Color(0xFF052E2B), Color(0xFF065F46), Color(0xFF0369A1), Color(0xFF0F172A))
    )

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).background(Color(0xFFF7FBFF)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(shape = RoundedCornerShape(30.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent)) {
            Box(Modifier.fillMaxWidth().background(gradient).padding(22.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        ModelLogo()
                        Column {
                            Text("PharmaCoach AI", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                            Text("Runtime Shell + One External Model", color = Color(0xFFD1FAE5), style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    Text(
                        "اپ سبک نصب می‌شود؛ مدل اصلی جداگانه به‌صورت zip وارد می‌شود تا بتوانی بارها مدل را آپدیت کنی، بدون اینکه هر بار کل اپ عوض شود.",
                        color = Color.White,
                        style = MaterialTheme.typography.bodyLarge
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AssistChip(onClick = {}, label = { Text(if (info.installed) "مدل فعال" else "مدل نصب نیست") })
                        AssistChip(onClick = {}, label = { Text("یک مدل واحد") })
                    }
                }
            }
        }

        ElevatedCard(shape = RoundedCornerShape(24.dp), colors = CardDefaults.elevatedCardColors(containerColor = Color.White)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("نصب و مدیریت مدل", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                Text(viewModel.modelMessage, color = if (info.installed) Color(0xFF047857) else Color(0xFF9A3412))
                if (viewModel.modelBusy) LinearProgressIndicator(Modifier.fillMaxWidth())

                StatusRow("وضعیت", if (info.installed) "نصب‌شده" else "در انتظار مدل")
                StatusRow("نسخه", info.version)
                StatusRow("حجم نصب‌شده", if (info.sizeBytes > 0) "${info.sizeBytes / 1024} KB" else "-")

                Button(
                    onClick = { modelPicker.launch(arrayOf("application/zip", "application/octet-stream", "application/x-zip-compressed")) },
                    enabled = !viewModel.modelBusy,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Icon(Icons.Default.FolderZip, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("انتخاب zip مدل از گوشی")
                }

                OutlinedButton(
                    onClick = { viewModel.downloadDefaultModel() },
                    enabled = !viewModel.modelBusy,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Icon(Icons.Default.CloudDownload, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("دانلود مدل از GitHub Release")
                }

                if (info.installed) {
                    Button(
                        onClick = onModelReady,
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Icon(Icons.Default.Verified, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("ورود به اپ")
                    }
                    OutlinedButton(
                        onClick = { viewModel.resetInstalledModel() },
                        enabled = !viewModel.modelBusy,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFB91C1C))
                    ) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("حذف مدل نصب‌شده")
                    }
                }
            }
        }

        ElevatedCard(shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("ساختار zip مدل", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                Text("داخل zip مدل باید همین سه فایل باشد. اپ خودش zip را باز، اعتبارسنجی و در حافظه امن داخلی برنامه نصب می‌کند:")
                CodeLine("pharma_course_fa.json")
                CodeLine("pharma_runtime_model_v12.json")
                CodeLine("pharma_runtime_manifest_v12.json")
                Text("فایل‌های خام آموزش و دیتاست‌های حجیم داخل اپ قرار نمی‌گیرند؛ فقط مدل runtime نهایی نصب می‌شود.", color = Color(0xFF475569))
            }
        }
    }
}

@Composable
private fun ModelLogo() {
    Box(Modifier.size(70.dp).clip(CircleShape).background(Brush.radialGradient(listOf(Color(0xFF34D399), Color(0xFF0EA5E9), Color(0xFF0F172A)))), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(52.dp)) {
            val green = Color(0xFFD1FAE5)
            val blue = Color(0xFFBAE6FD)
            drawLine(green, Offset(size.width * .2f, size.height * .5f), Offset(size.width * .8f, size.height * .5f), strokeWidth = 7f, cap = StrokeCap.Round)
            drawLine(blue, Offset(size.width * .5f, size.height * .2f), Offset(size.width * .5f, size.height * .8f), strokeWidth = 7f, cap = StrokeCap.Round)
            drawCircle(Color.White.copy(alpha = .95f), radius = 6f, center = Offset(size.width * .5f, size.height * .5f))
            drawCircle(green, radius = 5f, center = Offset(size.width * .2f, size.height * .5f))
            drawCircle(blue, radius = 5f, center = Offset(size.width * .8f, size.height * .5f))
        }
    }
}

@Composable
private fun StatusRow(title: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color(0xFF64748B))
        Text(value, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
    }
}

@Composable
private fun CodeLine(text: String) {
    Surface(color = Color(0xFFEFF6FF), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
        Text(text, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), color = Color(0xFF075985), fontWeight = FontWeight.Bold)
    }
}
