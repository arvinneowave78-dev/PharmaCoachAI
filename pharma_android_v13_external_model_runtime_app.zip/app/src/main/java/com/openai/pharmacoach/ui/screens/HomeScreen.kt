package com.openai.pharmacoach.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.openai.pharmacoach.PharmaViewModel

@Composable
fun HomeScreen(
    viewModel: PharmaViewModel,
    onOpenChapter: (String) -> Unit,
    onStartDiagnostic: () -> Unit,
    onInstallModel: () -> Unit
) {
    val course = viewModel.course
    LazyColumn(Modifier.fillMaxSize().background(Color(0xFFF7FBFF)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(30.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent)) {
                Box(Modifier.background(Brush.linearGradient(listOf(Color(0xFF064E3B), Color(0xFF0E7490), Color(0xFF1E3A8A), Color(0xFF0F172A)))).padding(22.dp)) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("PharmaCoach AI", style = MaterialTheme.typography.headlineMedium, color = Color.White, fontWeight = FontWeight.Black)
                        Text("پوسته حرفه‌ای + مدل خارجی قابل آپدیت؛ سؤال‌پرس پویا، تدریس شخصی، دام آموزشی، ذخیره نکته و PDF نکات.", color = Color.White)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AssistChip(onClick = { }, label = { Text("سطح: ${viewModel.levelLabel()}") })
                            AssistChip(onClick = { }, label = { Text(if (viewModel.modelInfo.installed) "مدل فعال" else "مدل نصب نیست") })
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(onClick = onStartDiagnostic, enabled = course != null) { Text("چالش هوشمند") }
                            OutlinedButton(onClick = onInstallModel, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) { Text("مدیریت مدل") }
                        }
                    }
                }
            }
        }

        if (course == null) {
            item {
                ElevatedCard(shape = RoundedCornerShape(24.dp), colors = CardDefaults.elevatedCardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("مدل نصب نشده", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                        Text("برای فعال شدن درس‌ها، آزمون‌ها، سطح‌بندی و تحلیل، zip مدل را از بخش «مدل» نصب کن.")
                        Button(onClick = onInstallModel, modifier = Modifier.fillMaxWidth()) { Text("رفتن به نصب مدل") }
                    }
                }
            }
            return@LazyColumn
        }

        item {
            ElevatedCard(shape = RoundedCornerShape(24.dp), colors = CardDefaults.elevatedCardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("استراتژی مدل", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                    Text("مدل سؤال‌ها را زیاد و کورکورانه نمی‌ریزد؛ با حداقل سؤالِ هدفمند، ضعف پنهان را پیدا می‌کند و همان‌جا تدریس می‌کند.")
                    Text("مبتدی ← تازه‌کار ← رو‌به‌تسلط ← پیشرفته ← استاد", color = Color(0xFF0369A1), fontWeight = FontWeight.Bold)
                }
            }
        }
        item { Text("فصل‌های مدل نصب‌شده", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black) }
        items(course.chapters) { ch ->
            ElevatedCard(Modifier.fillMaxWidth().clickable { onOpenChapter(ch.id) }, shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(ch.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                    Text(ch.subtitle)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        AssistChip(onClick = { }, label = { Text("${ch.estimatedMinutes} دقیقه") })
                        AssistChip(onClick = { }, label = { Text("${ch.questions.size} تست") })
                        AssistChip(onClick = { }, label = { Text("${ch.sections.size} بخش") })
                    }
                }
            }
        }
    }
}
