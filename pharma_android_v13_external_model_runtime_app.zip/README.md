# PharmaCoach AI v13 External Model Runtime

این نسخه اپ را از مدل جدا می‌کند.

## معماری
- APK فقط پوسته اجرایی، UI/UX، موتور نصب مدل، موتور آزمون، تحلیل و PDF ساز است.
- مدل فقط یک zip جداست و بعد از نصب برنامه از بخش «مدل» وارد می‌شود.
- فایل‌های خام آموزش، دیتاست‌های حجیم و memory pack داخل اپ نیستند.

## zip مدل باید شامل این فایل‌ها باشد
- `pharma_course_fa.json`
- `pharma_runtime_model_v12.json`
- `pharma_runtime_manifest_v12.json`

## آپدیت مدل
برای آپدیت مدل لازم نیست کل اپ را عوض کنی. کافی است zip مدل جدید را از بخش «مدل» انتخاب کنی یا آن را در GitHub Release قرار بدهی.

## Build
GitHub Actions داخل `.github/workflows/android.yml` آماده است.
