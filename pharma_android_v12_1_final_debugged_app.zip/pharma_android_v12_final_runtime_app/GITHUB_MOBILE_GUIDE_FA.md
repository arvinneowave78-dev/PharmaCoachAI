# راهنمای ساخت APK با موبایل و GitHub

این پروژه برای ساخت خودکار APK در GitHub آماده شده است. لازم نیست روی گوشی Gradle یا Android Studio نصب کنی.

## مرحله ۱: ساخت حساب GitHub
1. با مرورگر گوشی برو به: `github.com`
2. روی **Sign up** بزن و حساب بساز.
3. ایمیل را تأیید کن.

## مرحله ۲: ساخت Repository جدید
1. بعد از ورود، روی علامت **+** بالای صفحه بزن.
2. گزینه **New repository** را انتخاب کن.
3. اسم را بگذار: `PharmaCoachAI`
4. حالت را روی **Private** بگذار اگر نمی‌خواهی کسی سورس را ببیند.
5. گزینه‌های README/gitignore/license را لازم نیست فعال کنی.
6. روی **Create repository** بزن.

## مرحله ۳: آپلود فایل‌های پروژه
1. فایل zip پروژه را در گوشی Extract کن.
2. داخل پوشه پروژه باید فایل‌هایی مثل `settings.gradle.kts` و پوشه `app` دیده شوند.
3. در صفحه Repository در GitHub روی **uploading an existing file** یا **Add file → Upload files** بزن.
4. همه فایل‌ها و پوشه‌های داخل پروژه را انتخاب و آپلود کن.
5. پایین صفحه روی **Commit changes** بزن.

اگر انتخاب پوشه در مرورگر گوشی سخت بود، از اپ GitHub یا مرورگر Chrome Desktop site استفاده کن:
- Chrome → سه نقطه بالا → فعال کردن **Desktop site**

## مرحله ۴: ساخت APK
1. داخل Repository برو به تب **Actions**.
2. اگر GitHub گفت workflowها غیرفعال‌اند، روی **I understand my workflows, go ahead and enable them** بزن.
3. workflow با نام **Build Android APK** را باز کن.
4. روی **Run workflow** بزن.
5. چند دقیقه صبر کن تا تیک سبز بگیرد.

## مرحله ۵: دانلود APK
1. همان صفحه اجرای workflow را باز کن.
2. پایین صفحه بخش **Artifacts** را پیدا کن.
3. فایل `PharmaCoachAI-v12-final-debug-apk` را دانلود کن.
4. فایل دانلودی zip است؛ بازش کن و APK داخلش را نصب کن.

## نکته نصب روی اندروید
اگر گوشی اجازه نصب نداد:
- Settings → Security / Privacy → Install unknown apps
- برای Chrome یا Files اجازه نصب بده.

## اگر build خطا داد
از تب Actions وارد اجرای قرمز شو، خطا را کپی کن و به ChatGPT بده. معمولاً خطاها مربوط به آپلود ناقص فایل‌ها یا جاافتادن پوشه `.github` هستند.
