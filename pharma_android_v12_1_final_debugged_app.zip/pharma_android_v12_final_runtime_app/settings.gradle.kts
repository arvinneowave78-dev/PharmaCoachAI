rootProject.name = "PharmaCoachAI"
include(":app")
