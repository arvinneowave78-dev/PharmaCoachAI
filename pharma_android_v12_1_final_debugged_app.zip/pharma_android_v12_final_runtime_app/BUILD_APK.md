# ساخت APK

این پروژه build-ready است. در GitHub Actions فایل `.github/workflows/android.yml` را اجرا کنید؛ خروجی APK در Artifact با نام `PharmaCoachAI-v12-final-debug-apk` ساخته می‌شود.

در Android Studio هم پروژه را باز کنید و از مسیر Build > Build Bundle(s) / APK(s) > Build APK(s) خروجی بگیرید.

نکته: این پکیج سورس اپ اندروید است و Gradle wrapper داخل آن قرار داده نشده است.
