package com.openai.pharmacoach.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.openai.pharmacoach.PharmaViewModel
import com.openai.pharmacoach.data.TreeNode

@Composable
fun ChapterScreen(viewModel: PharmaViewModel, onStartQuiz: (String) -> Unit, onShareMindMap: () -> Unit) {
    val ch = viewModel.currentChapter ?: return
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(ch.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text(ch.subtitle)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { onStartQuiz(ch.id) }) { Text("شروع آزمون فصل") }
                        OutlinedButton(onClick = onShareMindMap) { Text("ساخت مایندمپ گرافیکی") }
                    }
                }
            }
        }
        item { Text("درس‌نامه", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        items(ch.sections) { section ->
            Card {
                Column(Modifier.padding(16.dp)) {
                    Text(section.heading, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(section.body, style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
        item { Text("رمزها و کلیدهای حفظی", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        items(ch.mnemonics) { m ->
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F3FF))) {
                Column(Modifier.padding(14.dp)) {
                    Text(m.title, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(m.content)
                }
            }
        }
        item { Text("درخت مفهومی", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { TreeNodeView(ch.tree) }
        item { Text("مایندمپ پایان فصل", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ch.mindMap.forEach { Text("• $it", modifier = Modifier.background(Color(0xFFEFF6FF)).padding(12.dp)) }
            }
        }
        item { Text("مرور طلایی", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ch.quickRecall.forEach { Text("- $it") }
            }
        }
    }
}

@Composable
private fun TreeNodeView(node: TreeNode, depth: Int = 0) {
    Column(Modifier.fillMaxWidth().padding(start = (depth * 12).dp)) {
        Text(text = if (depth == 0) node.label else "↳ ${node.label}", fontWeight = if (depth == 0) FontWeight.Bold else FontWeight.Normal)
        node.children.forEach { TreeNodeView(it, depth + 1) }
    }
}
