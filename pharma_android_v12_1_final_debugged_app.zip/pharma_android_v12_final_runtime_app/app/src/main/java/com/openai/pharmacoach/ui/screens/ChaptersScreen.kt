package com.openai.pharmacoach.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.openai.pharmacoach.PharmaViewModel

@Composable
fun ChaptersScreen(viewModel: PharmaViewModel, onOpen: (String) -> Unit) {
    val course = viewModel.course ?: return
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("مسیر یادگیری", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        items(course.chapters) { ch ->
            OutlinedCard(Modifier.fillMaxWidth().clickable { onOpen(ch.id) }) {
                Column(Modifier.padding(16.dp)) {
                    Text(ch.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(ch.subtitle)
                    Spacer(Modifier.height(8.dp))
                    Text("بخش‌ها: ${ch.sections.size} | رمزها: ${ch.mnemonics.size} | تست‌ها: ${ch.questions.size}")
                }
            }
        }
    }
}
