package com.openai.pharmacoach.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.openai.pharmacoach.PharmaViewModel

@Composable
fun QuizScreen(viewModel: PharmaViewModel) {
    val questions = viewModel.quizQuestions
    if (questions.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
            Text("هنوز آزمونی شروع نشده است.")
        }
        return
    }
    val q = questions[viewModel.currentIndex]
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("سؤال ${viewModel.currentIndex + 1} از ${questions.size}", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AssistChip(onClick = { }, label = { Text("سختی ${q.difficulty}") })
            AssistChip(onClick = { }, label = { Text(q.questionType) })
            AssistChip(onClick = { }, label = { Text(q.objective) })
        }
        Text(q.prompt, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        q.options.forEachIndexed { index, opt ->
            OutlinedButton(onClick = { if (viewModel.explanation == null) viewModel.answer(index) }, modifier = Modifier.fillMaxWidth()) {
                Text(opt)
            }
        }
        viewModel.explanation?.let { exp ->
            Card(colors = CardDefaults.cardColors(containerColor = if (viewModel.selectedCorrect == true) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer)) {
                Column(Modifier.padding(16.dp)) {
                    Text(if (viewModel.selectedCorrect == true) "درست" else "نیاز به مرور", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(exp)
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = { viewModel.saveCurrentQuestionNote() }) {
                        Text("ذخیره نکته این سؤال")
                    }
                }
            }
            Button(onClick = { viewModel.nextQuestion() }, enabled = !viewModel.isQuizFinished()) { Text("سؤال بعدی") }
            if (viewModel.isQuizFinished()) {
                Text("آزمون تمام شد. به تب تحلیل برو.", fontWeight = FontWeight.Bold)
            }
        }
    }
}
