package com.openai.pharmacoach.domain

import com.openai.pharmacoach.data.Chapter
import com.openai.pharmacoach.data.Course
import com.openai.pharmacoach.data.DomainScore
import com.openai.pharmacoach.data.LearnerSnapshot
import com.openai.pharmacoach.data.Question
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlin.math.exp
import kotlin.math.roundToInt

data class AnswerLog(
    val questionId: String,
    val chapterId: String,
    val domainId: String,
    val difficulty: String,
    val type: String,
    val correct: Boolean,
    val selectedIndex: Int,
    val expectedIndex: Int,
    val durationMs: Long,
    val masteryBefore: Int,
    val masteryAfter: Int
)

class AdaptiveEngine(private val course: Course, modelText: String? = null) {
    private val model = modelText?.let { runCatching { Json.parseToJsonElement(it).jsonObject }.getOrNull() }
    private val states = linkedMapOf<String, MutableDomainState>()
    private val logs = mutableListOf<AnswerLog>()
    private val difficultyWeights = mapOf("A" to 1.0, "B" to 1.8, "C" to 2.7, "D" to 3.8, "E" to 5.0)

    init {
        course.chapters.forEach { chapter ->
            val prior = model?.get("domainPriors")?.jsonObject?.get(chapter.skill)?.jsonObject?.get("initial_mastery")?.jsonPrimitive?.intOrNull ?: 30
            states.putIfAbsent(chapter.skill, MutableDomainState(chapter.skill, chapter.title, mastery = prior.coerceIn(0, 100)))
        }
    }

    fun answer(chapter: Chapter, question: Question, selectedIndex: Int, durationMs: Long) {
        val state = states.getValue(chapter.skill)
        val before = state.mastery
        val correct = selectedIndex == question.answerIndex
        val weight = difficultyWeights[question.difficulty.uppercase()] ?: 2.0
        val discrimination = when {
            question.questionType.contains("استاد") -> 1.65
            question.questionType.contains("بالینی") || question.questionType.contains("اورژانسی") -> 1.45
            question.questionType.contains("ترکیبی") -> 1.35
            question.questionType.contains("دام") -> 1.10
            else -> 0.90
        }
        val speedQuality = when {
            durationMs == 0L -> 0.65
            durationMs < 7000 -> 0.95
            durationMs < 16000 -> 0.75
            else -> 0.45
        }
        state.attempts += 1
        if (correct) state.correct += 1
        val expected = sigmoid((state.mastery - (40 + weight * 8)) / 18.0)
        val surprise = if (correct) (1.0 - expected) else expected
        val delta = ((if (correct) 1 else -1) * (4.0 + weight * discrimination) * (0.75 + surprise) * speedQuality).roundToInt()
        state.mastery = (state.mastery + delta).coerceIn(0, 100)
        state.accuracy = ((state.correct.toDouble() / state.attempts) * 100).roundToInt()
        state.theta = ((state.mastery - 50) / 16.7).coerceIn(-3.0, 3.0)
        state.speedIndex = (((state.speedIndex * (state.attempts - 1)) + (speedQuality * 100).roundToInt()) / state.attempts).coerceIn(0,100)
        state.retentionRisk = (100 - ((state.mastery * 0.55) + (state.accuracy * 0.25) + (state.speedIndex * 0.20)).roundToInt()).coerceIn(0, 100)
        if (!correct) state.mistakes += inferMistake(question)
        logs += AnswerLog(question.id, chapter.id, chapter.skill, question.difficulty, question.questionType, correct, selectedIndex, question.answerIndex, durationMs, before, state.mastery)
    }

    private fun sigmoid(x: Double): Double = 1.0 / (1.0 + exp(-x))

    private fun inferMistake(question: Question): String = when {
        question.objective.contains("دوز") || question.objective.contains("رقت") -> "اشتباه دوز/رقت"
        question.objective.contains("راه") || question.tags.any { it.contains("routes") } -> "اشتباه راه تجویز"
        question.questionType.contains("بالینی") || question.questionType.contains("اورژانسی") -> "اشتباه سناریویی-بالینی"
        question.tags.any { it.contains("adrenergic") || it.contains("ans") || it.contains("cholinergic") || it.contains("epinephrine") } -> "اشتباه گیرنده/اثر"
        question.questionType.contains("دام") -> "شتاب‌زدگی/دام گزینه‌ای"
        else -> "تمایز مفهومی"
    }

    fun overallScore(): Int = if (states.isEmpty()) 0 else states.values.map { it.mastery }.average().roundToInt()

    fun levelLabel(): String = when (overallScore()) {
        in 0..24 -> "مبتدی"
        in 25..44 -> "تازه‌کار"
        in 45..64 -> "رو‌به‌تسلط"
        in 65..84 -> "پیشرفته"
        else -> "استاد"
    }

    fun recommendedChapterIds(): List<String> = course.chapters.sortedWith(compareBy<Chapter> { states[it.skill]?.mastery ?: 0 }.thenByDescending { states[it.skill]?.retentionRisk ?: 0 }).map { it.id }

    fun recommendedStudyPlan(): List<String> {
        val low = states.values.sortedWith(compareBy<MutableDomainState> { it.mastery }.thenByDescending { it.retentionRisk }).take(3)
        val list = mutableListOf<String>()
        low.forEach { st ->
            val common = st.mistakes.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key ?: "تمایز مفهومی"
            val visual = when (common) {
                "اشتباه دوز/رقت" -> "فلوچارت دوز و رقت"
                "اشتباه گیرنده/اثر" -> "نقشه گیرنده→اندام→اثر"
                "اشتباه راه تجویز" -> "درخت راه‌های تجویز"
                else -> "مایندمپ خلاصه فصل"
            }
            list += "${st.title}: $visual + ۸ سؤال نزدیک‌گزینه + مرور ${if (st.retentionRisk > 55) "۲۴ ساعت" else "۷۲ ساعت"} بعد"
        }
        if (levelLabel() == "استاد") list += "سطح استاد: ورود به بانک سؤال سناریویی چنددارویی و تحلیل پروتکل."
        return list
    }

    fun snapshot(learnerName: String = "کاربر"): LearnerSnapshot {
        val ordered = states.values.sortedByDescending { it.mastery }
        val strengths = ordered.take(3).map { "${it.title} (${it.mastery}٪)" }
        val weaknesses = ordered.sortedBy { it.mastery }.take(3).map { "${it.title} (${it.mastery}٪، ریسک فراموشی ${it.retentionRisk}٪)" }
        val mistakePatterns = states.values.flatMap { it.mistakes }.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(6).map { "${it.key}: ${it.value}" }
        return LearnerSnapshot(
            learnerName = learnerName,
            overallScore = overallScore(),
            levelLabel = levelLabel(),
            strengths = strengths,
            weaknesses = weaknesses,
            recommendations = recommendedStudyPlan(),
            domainScores = ordered.map { it.toPublic() },
            answeredQuestionIds = logs.map { it.questionId },
            mistakePatterns = mistakePatterns
        )
    }

    fun developerPayload(): Map<String, Any> = mapOf(
        "modelVersion" to "0.8.0-trained-structured",
        "overallScore" to overallScore(),
        "level" to levelLabel(),
        "recommendedChapterIds" to recommendedChapterIds(),
        "recommendedStudyPlan" to recommendedStudyPlan(),
        "answerLogs" to logs.map { mapOf(
            "questionId" to it.questionId,
            "chapterId" to it.chapterId,
            "domainId" to it.domainId,
            "difficulty" to it.difficulty,
            "type" to it.type,
            "correct" to it.correct,
            "durationMs" to it.durationMs,
            "masteryBefore" to it.masteryBefore,
            "masteryAfter" to it.masteryAfter
        ) },
        "domains" to states.values.map { mapOf(
            "domainId" to it.domainId,
            "title" to it.title,
            "mastery" to it.mastery,
            "theta" to it.theta,
            "accuracy" to it.accuracy,
            "speedIndex" to it.speedIndex,
            "retentionRisk" to it.retentionRisk,
            "attempts" to it.attempts,
            "mistakes" to it.mistakes
        ) }
    )
}

private data class MutableDomainState(
    val domainId: String,
    val title: String,
    var mastery: Int = 30,
    var theta: Double = -1.2,
    var attempts: Int = 0,
    var correct: Int = 0,
    var accuracy: Int = 0,
    var speedIndex: Int = 50,
    var retentionRisk: Int = 70,
    val mistakes: MutableList<String> = mutableListOf()
) {
    fun toPublic(): DomainScore = DomainScore(domainId, title, mastery, speedIndex, attempts, accuracy)
}
