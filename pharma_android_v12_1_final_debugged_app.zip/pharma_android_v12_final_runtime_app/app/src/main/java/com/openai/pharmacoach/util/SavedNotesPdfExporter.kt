package com.openai.pharmacoach.util

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import com.openai.pharmacoach.data.LearnerSnapshot
import com.openai.pharmacoach.data.SavedQuestionNote
import java.io.File
import java.io.FileOutputStream

object SavedNotesPdfExporter {
    fun export(context: Context, notes: List<SavedQuestionNote>, snapshot: LearnerSnapshot?): File {
        val document = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(17, 24, 39)
            textSize = 22f
            typeface = Typeface.create(Typeface.DEFAULT_BOLD, Typeface.BOLD)
        }
        val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(71, 85, 105)
            textSize = 12f
        }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(15, 23, 42)
            textSize = 10.5f
        }
        val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(71, 85, 105)
            textSize = 9f
        }
        var pageNumber = 1

        fun newPage(): Pair<PdfDocument.Page, Canvas> {
            val page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber++).create())
            val canvas = page.canvas
            canvas.drawColor(Color.rgb(248, 250, 252))
            return page to canvas
        }

        var (page, canvas) = newPage()
        canvas.drawText("دفترچه نکات شخصی فارما", 40f, 60f, titlePaint)
        canvas.drawText("ساخته‌شده از نکاتی که خودت هنگام آزمون ذخیره کرده‌ای", 40f, 84f, subtitlePaint)
        snapshot?.let {
            canvas.drawText("سطح فعلی: ${it.levelLabel} | امتیاز: ${it.overallScore}٪", 40f, 110f, bodyPaint)
            canvas.drawText("تمرکز پیشنهادی: ${it.weaknesses.joinToString("، ")}", 40f, 130f, smallPaint)
        }
        canvas.drawText("تعداد نکات ذخیره‌شده: ${notes.size}", 40f, 155f, bodyPaint)
        document.finishPage(page)

        var y = 48f
        var pair = newPage()
        page = pair.first
        canvas = pair.second

        notes.forEachIndexed { index, note ->
            if (y > 690f) {
                document.finishPage(page)
                pair = newPage()
                page = pair.first
                canvas = pair.second
                y = 48f
            }
            drawNoteCard(canvas, 32f, y, pageWidth - 64f, note, index + 1, titlePaint, bodyPaint, smallPaint)
            y += 178f
        }
        document.finishPage(page)

        val out = File(context.cacheDir, "pharma_saved_notes.pdf")
        FileOutputStream(out).use { document.writeTo(it) }
        document.close()
        return out
    }

    private fun drawNoteCard(
        canvas: Canvas,
        x: Float,
        y: Float,
        w: Float,
        note: SavedQuestionNote,
        number: Int,
        title: Paint,
        body: Paint,
        small: Paint
    ) {
        val card = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(99, 102, 241)
            style = Paint.Style.STROKE
            strokeWidth = 1.3f
        }
        canvas.drawRoundRect(RectF(x, y, x + w, y + 150f), 18f, 18f, card)
        canvas.drawRoundRect(RectF(x, y, x + w, y + 150f), 18f, 18f, border)
        canvas.drawText("$number. ${note.domain}", x + 16f, y + 26f, title.apply { textSize = 15f })
        canvas.drawText("اصل: ${shorten(note.coreNote, 88)}", x + 16f, y + 52f, body)
        canvas.drawText("دام: ${shorten(note.trapNote, 88)}", x + 16f, y + 74f, body)
        canvas.drawText("نقشه: ${shorten(note.arrowNote, 80)}", x + 16f, y + 96f, body)
        drawArrow(canvas, x + 20f, y + 113f, x + w - 24f, y + 113f)
        canvas.drawText("مرور: ${shorten(note.reviewPrompt, 90)}", x + 16f, y + 136f, small)
    }

    private fun drawArrow(canvas: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(14, 165, 233)
            strokeWidth = 2.2f
        }
        canvas.drawLine(x1, y1, x2, y2, p)
        canvas.drawLine(x2, y2, x2 - 9f, y2 - 5f, p)
        canvas.drawLine(x2, y2, x2 - 9f, y2 + 5f, p)
    }

    private fun shorten(text: String, max: Int): String = if (text.length <= max) text else text.take(max - 1) + "…"
}
