package com.openai.pharmacoach.util

import android.content.Context
import android.util.Base64
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import java.io.File
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

object EncryptedExportUtil {
    private val json = Json { prettyPrint = true }

    fun export(context: Context, payload: Map<String, Any>): File {
        val raw = json.encodeToString(JsonElement.serializer(), toJsonElement(payload))
        val seed = MessageDigest.getInstance("SHA-256").digest((context.packageName + "::PharmaCoachAI::developer-export::v8").toByteArray())
        val key = SecretKeySpec(seed.copyOf(16), "AES")
        val iv = ByteArray(12) { i -> (i * 17 + 11).toByte() }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        val encrypted = cipher.doFinal(raw.toByteArray())
        val out = File(context.cacheDir, "pharma_developer_bundle_v8.enc")
        out.writeText(Base64.encodeToString(encrypted, Base64.NO_WRAP))
        return out
    }

    @Suppress("UNCHECKED_CAST")
    private fun toJsonElement(value: Any?): JsonElement = when (value) {
        null -> JsonPrimitive(null as String?)
        is String -> JsonPrimitive(value)
        is Number -> JsonPrimitive(value)
        is Boolean -> JsonPrimitive(value)
        is Map<*, *> -> JsonObject(value.entries.associate { it.key.toString() to toJsonElement(it.value) })
        is Iterable<*> -> JsonArray(value.map { toJsonElement(it) })
        else -> JsonPrimitive(value.toString())
    }
}
