package com.openai.pharmacoach

import android.app.Application
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.openai.pharmacoach.data.Chapter
import com.openai.pharmacoach.data.Course
import com.openai.pharmacoach.data.CourseRepository
import com.openai.pharmacoach.data.Question
import com.openai.pharmacoach.domain.AdaptiveEngine
import com.openai.pharmacoach.util.EncryptedExportUtil
import com.openai.pharmacoach.util.EducatorReportGenerator
import com.openai.pharmacoach.util.MindMapImageGenerator
import com.openai.pharmacoach.data.SavedQuestionNote
import com.openai.pharmacoach.domain.DynamicTutorV11
import com.openai.pharmacoach.util.SavedNotesPdfExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

class PharmaViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = CourseRepository(app.applicationContext)
    var course by mutableStateOf<Course?>(null)
        private set
    var currentChapter by mutableStateOf<Chapter?>(null)
        private set
    var quizQuestions by mutableStateOf<List<Question>>(emptyList())
        private set
    var currentIndex by mutableStateOf(0)
        private set
    var explanation by mutableStateOf<String?>(null)
        private set
    var selectedCorrect by mutableStateOf<Boolean?>(null)
        private set
    var learnerName by mutableStateOf("کاربر")
    private var engine: AdaptiveEngine? = null
    private var tutorV11: DynamicTutorV11? = null
    val savedNotes = mutableStateListOf<SavedQuestionNote>()
    private var questionStartTime: Long = 0L

    init { load() }

    private fun load() {
        viewModelScope.launch(Dispatchers.IO) {
            val c = repo.loadCourse()
            course = c
            engine = AdaptiveEngine(c, repo.loadAiModelText())
            tutorV11 = DynamicTutorV11(
                repo.loadAiModelText(),
                repo.loadAiModelText()
            )
        }
    }

    fun openChapter(id: String) {
        currentChapter = course?.chapters?.firstOrNull { it.id == id }
    }

    fun startQuiz(chapterId: String? = null) {
        val c = course ?: return
        if (chapterId == null) {
            quizQuestions = c.chapters.flatMap { chapter -> chapter.questions.takeLast(3) + chapter.questions.take(2) }.shuffled().take(20)
            currentChapter = null
        } else {
            currentChapter = c.chapters.firstOrNull { it.id == chapterId }
            quizQuestions = currentChapter?.questions?.shuffled() ?: emptyList()
        }
        currentIndex = 0
        explanation = null
        selectedCorrect = null
        questionStartTime = System.currentTimeMillis()
    }

    fun startAdaptiveChallenge() {
        val c = course ?: return
        val snap = engine?.snapshot(learnerName)
        quizQuestions = tutorV11?.generateAdaptiveSession(c, snap, 24) ?: c.chapters.flatMap { it.questions }.shuffled().take(24)
        currentChapter = null
        currentIndex = 0
        explanation = null
        selectedCorrect = null
        questionStartTime = System.currentTimeMillis()
    }

    fun answer(selectedIndex: Int) {
        val q = quizQuestions.getOrNull(currentIndex) ?: return
        val chapter = currentChapter ?: course?.chapters?.firstOrNull { ch -> ch.questions.any { it.id == q.id } } ?: return
        val duration = (System.currentTimeMillis() - questionStartTime).coerceAtLeast(0L)
        engine?.answer(chapter, q, selectedIndex, duration)
        selectedCorrect = selectedIndex == q.answerIndex
        explanation = q.explanation
    }

    fun nextQuestion() {
        if (currentIndex < quizQuestions.lastIndex) {
            currentIndex += 1
            explanation = null
            selectedCorrect = null
            questionStartTime = System.currentTimeMillis()
        }
    }

    fun isQuizFinished(): Boolean = currentIndex >= quizQuestions.lastIndex && explanation != null

    fun levelLabel(): String = engine?.levelLabel() ?: "مبتدی"

    fun snapshotText(): String {
        val snap = engine?.snapshot(learnerName) ?: return "هنوز داده‌ای ثبت نشده است."
        return buildString {
            appendLine("گزارش یادگیری ${snap.learnerName}")
            appendLine("سطح کلی: ${snap.levelLabel} | امتیاز: ${snap.overallScore}٪")
            appendLine("نقاط قوت:")
            snap.strengths.forEach { appendLine("- $it") }
            appendLine("نقاط ضعف:")
            snap.weaknesses.forEach { appendLine("- $it") }
            appendLine("نسخه پیشنهادی موتور:")
            snap.recommendations.forEach { appendLine("- $it") }
            appendLine("الگوهای خطا:")
            snap.mistakePatterns.forEach { appendLine("- $it") }
        }
    }

    fun exportEncryptedDeveloperFile(onDone: (File) -> Unit) {
        val payload = engine?.developerPayload() ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val file = EncryptedExportUtil.export(getApplication(), payload)
            onDone(file)
        }
    }

    fun shareEducatorGraphic(onIntentReady: (Intent) -> Unit) {
        val snap = engine?.snapshot(learnerName) ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val file = EducatorReportGenerator.render(getApplication(), snap)
            shareFile(file, "image/png", onIntentReady)
        }
    }

    fun shareCurrentChapterMindMap(onIntentReady: (Intent) -> Unit) {
        val chapter = currentChapter ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val file = MindMapImageGenerator.render(getApplication(), chapter)
            shareFile(file, "image/png", onIntentReady)
        }
    }

    fun saveCurrentQuestionNote() {
        val q = quizQuestions.getOrNull(currentIndex) ?: return
        val note = tutorV11?.buildNote(q) ?: SavedQuestionNote(
            id = "NOTE_${q.id}_${System.currentTimeMillis()}",
            questionPrompt = q.prompt,
            correctAnswer = q.options.getOrNull(q.answerIndex) ?: "",
            coreNote = q.explanation,
            trapNote = "دام آموزشی از توضیح سؤال استخراج نشد.",
            arrowNote = "مفهوم → اثر → تصمیم EMT",
            miniCase = "این نکته را در یک کیس کوتاه مرور کن.",
            reviewPrompt = "چرا پاسخ درست از گزینه‌های نزدیک دقیق‌تر بود؟",
            domain = q.tags.firstOrNull() ?: "فارما",
            createdAtMillis = System.currentTimeMillis()
        )
        if (savedNotes.none { it.questionPrompt == note.questionPrompt && it.coreNote == note.coreNote }) {
            savedNotes.add(note)
        }
    }

    fun shareSavedNotesPdf(onIntentReady: (Intent) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val file = SavedNotesPdfExporter.export(getApplication(), savedNotes.toList(), engine?.snapshot(learnerName))
            shareFile(file, "application/pdf", onIntentReady)
        }
    }

    private fun shareFile(file: File, mime: String, onIntentReady: (Intent) -> Unit) {
        val uri = FileProvider.getUriForFile(getApplication(), "com.openai.pharmacoach.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        onIntentReady(intent)
    }
}
