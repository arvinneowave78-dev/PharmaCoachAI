package com.openai.pharmacoach.domain

import com.openai.pharmacoach.data.Chapter
import com.openai.pharmacoach.data.Course
import com.openai.pharmacoach.data.LearnerSnapshot
import com.openai.pharmacoach.data.Question
import com.openai.pharmacoach.data.SavedQuestionNote
import kotlin.math.abs
import kotlin.random.Random

data class GeneratedQuestionContext(
    val intent: String,
    val hiddenWeakness: String,
    val trap: String,
    val whyAsked: String,
    val saveableCore: String,
    val arrow: String,
    val miniCase: String,
    val reviewPrompt: String
)

class DynamicTutorV11(private val runtimeModelText: String? = null, private val blueprintText: String? = null) {
    private val random = Random(20260206)

    fun generateAdaptiveSession(course: Course, snapshot: LearnerSnapshot?, count: Int = 18): List<Question> {
        val weakText = snapshot?.weaknesses?.joinToString(" ") ?: ""
        val targetChapters = rankChapters(course, weakText).ifEmpty { course.chapters }
        return (0 until count).map { i ->
            val chapter = targetChapters[i % targetChapters.size]
            generateQuestion(chapter, i, weakText, expert = (snapshot?.levelLabel == "پیشرفته" || snapshot?.levelLabel == "استاد"))
        }
    }

    fun generateQuestion(chapter: Chapter, index: Int, weakText: String, expert: Boolean): Question {
        val seedSection = chapter.sections.getOrNull(index % chapter.sections.size)
        val heading = seedSection?.heading ?: chapter.title
        val body = seedSection?.body ?: chapter.subtitle
        val intent = chooseIntent(weakText, expert, index)
        val trap = chooseTrap(chapter.skill, weakText)
        val correct = buildCorrectOption(chapter.skill, heading, body)
        val distractors = buildNearDistractors(chapter.skill, trap, correct)
        val options = (listOf(correct) + distractors).distinct().take(4).shuffled(random)
        val answer = options.indexOf(correct).coerceAtLeast(0)
        val difficulty = if (expert) "E" else when (index % 4) { 0 -> "C"; 1 -> "D"; 2 -> "B"; else -> "D" }
        val prompt = if (expert) {
            "کیس استادسنج: در مبحث «${chapter.title}»، فردی پاسخ حفظی می‌دهد اما در تصمیم صحنه دچار دام می‌شود. با هدف «$intent»، کدام تحلیل دقیق‌تر است؟"
        } else {
            "سؤال تطبیقی: در مبحث «${chapter.title}»، کدام گزینه دقیق‌تر است و دام «$trap» را دور می‌زند؟"
        }
        return Question(
            id = "V12_GEN_${chapter.id}_${index}_${abs(prompt.hashCode())}",
            prompt = prompt,
            options = options,
            answerIndex = answer,
            explanation = buildPersonalizedExplanation(intent, trap, correct, chapter.skill),
            difficulty = difficulty,
            questionType = if (expert) "تولیدی استادسنج/کیس‌محور" else "تولیدی تطبیقی",
            tags = listOf(chapter.skill, "v12_runtime", intent),
            objective = "تشخیص $intent در ${chapter.title}"
        )
    }

    fun buildNote(question: Question): SavedQuestionNote {
        val correct = question.options.getOrNull(question.answerIndex) ?: "پاسخ صحیح"
        val domain = question.tags.firstOrNull() ?: "general"
        val core = extractCoreNote(question, correct)
        val trap = extractTrap(question)
        return SavedQuestionNote(
            id = "NOTE_${question.id}_${System.currentTimeMillis()}",
            questionPrompt = question.prompt,
            correctAnswer = correct,
            coreNote = core,
            trapNote = trap,
            arrowNote = "${domainLabel(domain)} → مفهوم کلیدی → تصمیم EMT → کاهش خطای صحنه",
            miniCase = "کیس کوتاه: اگر همین دام در صحنه با فشار زمانی رخ دهد، اول راه/دوز/گیرنده را دوباره چک کن.",
            reviewPrompt = "بدون نگاه کردن توضیح بده چرا گزینه درست با زمینه سؤال سازگارتر از دام نزدیک است.",
            domain = domain,
            createdAtMillis = System.currentTimeMillis()
        )
    }

    private fun rankChapters(course: Course, weakText: String): List<Chapter> {
        val scored = course.chapters.map { ch ->
            val score = listOf(ch.skill, ch.title, ch.subtitle).sumOf { token ->
                if (weakText.contains(token, ignoreCase = true)) 3 else 0
            } + when {
                weakText.contains("دوز") && ch.title.contains("اپی") -> 8
                weakText.contains("گیرنده") && (ch.skill.contains("adrenergic") || ch.skill.contains("ans")) -> 8
                weakText.contains("PK") && ch.skill.contains("pk") -> 8
                else -> 0
            }
            ch to score
        }.sortedByDescending { it.second }
        return scored.filter { it.second > 0 }.map { it.first }.ifEmpty { course.chapters.sortedByDescending { it.questions.size } }
    }

    private fun chooseIntent(weakText: String, expert: Boolean, index: Int): String = when {
        weakText.contains("دوز") || weakText.contains("رقت") -> "dose_route_pressure"
        weakText.contains("گیرنده") -> "separate_close_concepts"
        weakText.contains("فراموشی") -> "retention_probe"
        expert && index % 2 == 0 -> "expert_trap"
        index % 3 == 0 -> "clinical_transfer"
        else -> "diagnose_hidden_weakness"
    }

    private fun chooseTrap(skill: String, weakText: String): String = when {
        skill.contains("epinephrine") -> "قاطی کردن 1/1000، 1/10000، IM و IV/IO"
        skill.contains("adrenergic") -> "جابه‌جایی α1/α2/β1/β2 در اثر اندامی"
        skill.contains("cholinergic") -> "قاطی کردن SLUDGE با توکسیدروم آنتی‌کولینرژیک"
        skill.contains("pk") -> "یکی گرفتن جذب، زیست‌دسترسی، clearance و نیمه‌عمر"
        skill.contains("pd") -> "اشتباه بین رقابتی، غیررقابتی و برگشت‌ناپذیر"
        weakText.isNotBlank() -> "انتقال پاسخ حفظی به زمینه غلط"
        else -> "گزینه درست اما خارج از زمینه بالینی"
    }

    private fun buildCorrectOption(skill: String, heading: String, body: String): String = when {
        skill.contains("epinephrine") -> "اول زمینه بالینی را مشخص کن؛ آنافیلاکسی معمولاً IM از 1/1000 است، CPR بالغ 1mg IV/IO هر ۳ تا ۵ دقیقه."
        skill.contains("adrenergic") -> "گیرنده را به اندام و اثر وصل کن؛ β1 بیشتر قلب، β2 بیشتر برونش، α1 بیشتر انقباض عروقی."
        skill.contains("cholinergic") -> "الگوی علائم را از روی سیستم بسنج؛ SLUDGE کولینرژیک است و خشکی/میدریاز/گیجی بیشتر آنتی‌کولینرژیک."
        skill.contains("pk") -> "اثر نهایی را با ADME تحلیل کن؛ راه، first-pass، اتصال پروتئینی، کبد و کلیه همزمان مهم‌اند."
        skill.contains("pd") -> "نوع اتصال و پاسخ گیرنده را جدا کن؛ آگونیست فعال می‌کند، آنتاگونیست می‌بندد و پاسخ را مهار می‌کند."
        else -> "پاسخ درست باید هم با مفهوم «$heading» و هم با زمینه بالینی سازگار باشد، نه فقط با یک جمله حفظی."
    }

    private fun buildNearDistractors(skill: String, trap: String, correct: String): List<String> {
        val common = listOf(
            "چون یک عبارت از نظر حفظی آشناست، بدون بررسی زمینه بالینی همان را انتخاب می‌کنیم.",
            "اول نام دارو یا گیرنده را حفظ می‌کنیم و راه تجویز، دوز و بیمار را بعداً بررسی می‌کنیم.",
            "اگر پاسخ در یک مبحث درست باشد، در همه کیس‌های مشابه هم درست است."
        )
        val domain = when {
            skill.contains("epinephrine") -> listOf(
                "در آنافیلاکسی همیشه ابتدا آنتی‌هیستامین کافی است و اپی‌نفرین مرحله بعد است.",
                "هر محلول اپی‌نفرین با هر رقتی برای هر راه تزریق قابل استفاده است.",
                "در CPR و آنافیلاکسی دوز و راه تفاوت مهمی ندارند."
            )
            skill.contains("adrenergic") -> listOf(
                "β1 گیرنده اصلی برونش است و β2 بیشتر قلب را تحریک می‌کند.",
                "α2 مانند α1 عمدتاً اثر تحریکی مستقیم روی عروق دارد.",
                "پروپرانولول چون بتابلاکر است در آسم همیشه بی‌خطرتر از β2 agonist است."
            )
            skill.contains("cholinergic") -> listOf(
                "خشکی دهان، میدریاز و گیجی همان SLUDGE هستند.",
                "آتروپین اثرات موسکارینی را تقویت می‌کند.",
                "مهار کولین‌استراز باعث کاهش ACh می‌شود."
            )
            else -> common
        }
        return (domain + common).filter { it != correct }.take(3)
    }

    private fun buildPersonalizedExplanation(intent: String, trap: String, correct: String, skill: String): String =
        "قصد سؤال: $intent\n" +
        "پاسخ صحیح: $correct\n" +
        "دام آموزشی: $trap\n" +
        "چرا این سؤال پرسیده شد؟ چون مدل می‌خواهد بفهمد پاسخ تو فقط حفظی است یا می‌توانی مفهوم را در زمینه بالینی، دوز، راه، گیرنده و پیامد صحنه به‌کار ببری.\n" +
        "نکته ذخیره‌شدنی: ${domainLabel(skill)} را همیشه به زنجیره «مفهوم → گیرنده/مسیر → اثر → تصمیم EMT» وصل کن.\n" +
        "سؤال بعدی باید یکی از همین دام‌ها را با شکل متفاوت بسنجد."

    private fun extractCoreNote(question: Question, correct: String): String =
        "اصل سؤال: ${question.objective}. پاسخ درست: $correct"

    private fun extractTrap(question: Question): String =
        question.explanation.lines().firstOrNull { it.contains("دام") } ?: "دام: گزینه نزدیک ممکن است در زمینه‌ای دیگر درست باشد اما در این سؤال غلط است."

    private fun domainLabel(domain: String): String = when {
        domain.contains("epinephrine") -> "اپی‌نفرین"
        domain.contains("adrenergic") -> "آدرنرژیک"
        domain.contains("cholinergic") -> "کولینرژیک/آنتی‌کولینرژیک"
        domain.contains("pk") -> "فارماکوکینتیک"
        domain.contains("pd") -> "فارماکودینامیک"
        else -> "فارما"
    }
}
