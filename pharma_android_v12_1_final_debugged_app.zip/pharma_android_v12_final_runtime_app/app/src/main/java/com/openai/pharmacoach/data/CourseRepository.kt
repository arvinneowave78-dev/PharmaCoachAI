package com.openai.pharmacoach.data

import android.content.Context
import kotlinx.serialization.json.Json

class CourseRepository(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true }

    fun loadCourse(): Course {
        val raw = context.assets.open("pharma_course_fa.json").bufferedReader().use { it.readText() }
        return json.decodeFromString(Course.serializer(), raw)
    }

    fun loadAiModelText(): String = context.assets.open("pharma_runtime_model_v12.json").bufferedReader().use { it.readText() }

    fun loadAssetTextOrNull(name: String): String? = runCatching {
        context.assets.open(name).bufferedReader().use { it.readText() }
    }.getOrNull()
}
