package com.openai.pharmacoach.util

import android.content.Context
import android.graphics.*
import com.openai.pharmacoach.data.Chapter
import com.openai.pharmacoach.data.TreeNode
import java.io.File
import java.io.FileOutputStream

object MindMapImageGenerator {
    fun render(context: Context, chapter: Chapter): File {
        val width = 1800
        val height = 2200
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val bg = Paint().apply { shader = LinearGradient(0f, 0f, width.toFloat(), height.toFloat(), intArrayOf(Color.parseColor("#FDF4FF"), Color.parseColor("#EFF6FF"), Color.parseColor("#ECFCCB")), null, Shader.TileMode.CLAMP) }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#111827"); textSize = 54f; typeface = Typeface.create(Typeface.DEFAULT_BOLD, Typeface.BOLD) }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0F172A"); textSize = 28f }
        val chipFill = Paint(Paint.ANTI_ALIAS_FLAG)
        canvas.drawText("مایندمپ گرافیکی | ${chapter.title}", 90f, 90f, titlePaint)
        canvas.drawText(chapter.subtitle, 90f, 132f, bodyPaint)
        drawNode(canvas, chapter.tree, 90f, 220f, 0, chipFill, bodyPaint)
        var y = 1450f
        canvas.drawText("نکات طلایی", 90f, y, titlePaint)
        y += 50f
        chapter.mindMap.forEachIndexed { idx, item ->
            drawBullet(canvas, 110f, y + idx * 58f, item, bodyPaint)
        }
        val file = File(context.cacheDir, "mindmap_${chapter.id}.png")
        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return file
    }

    private fun drawNode(canvas: Canvas, node: TreeNode, x: Float, y: Float, depth: Int, fill: Paint, text: Paint): Float {
        val colors = listOf("#DBEAFE", "#E9D5FF", "#FCE7F3", "#DCFCE7", "#FEF3C7")
        fill.color = Color.parseColor(colors[depth % colors.size])
        val rect = RectF(x, y, x + 420f, y + 58f)
        canvas.drawRoundRect(rect, 22f, 22f, fill)
        val tx = x + 18f
        val ty = y + 38f
        canvas.drawText(node.label, tx, ty, text)
        var cursorY = y + 92f
        node.children.forEach { child ->
            canvas.drawLine(x + 40f, y + 58f, x + 70f, cursorY, Paint().apply { color = Color.parseColor("#94A3B8"); strokeWidth = 4f })
            cursorY = drawNode(canvas, child, x + 80f, cursorY, depth + 1, fill, text) + 18f
        }
        return maxOf(cursorY, y + 64f)
    }

    private fun drawBullet(canvas: Canvas, x: Float, y: Float, textValue: String, paint: Paint) {
        canvas.drawCircle(x, y - 10f, 6f, Paint().apply { color = Color.parseColor("#7C3AED") })
        canvas.drawText(textValue, x + 18f, y, paint)
    }
}
