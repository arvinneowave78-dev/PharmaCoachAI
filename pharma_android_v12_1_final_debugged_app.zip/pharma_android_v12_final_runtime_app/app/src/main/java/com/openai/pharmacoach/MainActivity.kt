package com.openai.pharmacoach

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.openai.pharmacoach.ui.PharmaApp
import com.openai.pharmacoach.ui.theme.PharmaTheme

class MainActivity : ComponentActivity() {
    private val viewModel: PharmaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PharmaTheme {
                PharmaApp(viewModel = viewModel)
            }
        }
    }
}
