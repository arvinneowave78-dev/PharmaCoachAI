package com.openai.pharmacoach.data

import kotlinx.serialization.Serializable

@Serializable
data class Course(val title: String, val language: String, val version: String, val description: String, val chapters: List<Chapter>)

@Serializable
data class Chapter(
    val id: String,
    val title: String,
    val subtitle: String,
    val estimatedMinutes: Int,
    val skill: String,
    val sections: List<Section>,
    val mnemonics: List<Mnemonic>,
    val tree: TreeNode,
    val mindMap: List<String>,
    val quickRecall: List<String>,
    val questions: List<Question>
)

@Serializable data class Section(val heading: String, val body: String)
@Serializable data class Mnemonic(val title: String, val content: String)
@Serializable data class TreeNode(val label: String, val children: List<TreeNode> = emptyList())

@Serializable
data class Question(
    val id: String,
    val prompt: String,
    val options: List<String>,
    val answerIndex: Int,
    val explanation: String,
    val difficulty: String,
    val questionType: String,
    val tags: List<String>,
    val objective: String
)

@Serializable
data class DomainScore(
    val domainId: String,
    val title: String,
    val mastery: Int = 0,
    val confidence: Int = 0,
    val attempts: Int = 0,
    val accuracy: Int = 0
)

@Serializable
data class LearnerSnapshot(
    val learnerName: String = "کاربر",
    val overallScore: Int = 0,
    val levelLabel: String = "مبتدی",
    val strengths: List<String> = emptyList(),
    val weaknesses: List<String> = emptyList(),
    val recommendations: List<String> = emptyList(),
    val domainScores: List<DomainScore> = emptyList(),
    val answeredQuestionIds: List<String> = emptyList(),
    val mistakePatterns: List<String> = emptyList()
)


@Serializable
data class SavedQuestionNote(
    val id: String,
    val questionPrompt: String,
    val correctAnswer: String,
    val coreNote: String,
    val trapNote: String,
    val arrowNote: String,
    val miniCase: String,
    val reviewPrompt: String,
    val domain: String,
    val createdAtMillis: Long
)
