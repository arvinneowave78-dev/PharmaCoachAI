package com.openai.pharmacoach.util

import android.content.Context
import android.graphics.*
import com.openai.pharmacoach.data.LearnerSnapshot
import java.io.File
import java.io.FileOutputStream

object EducatorReportGenerator {
    fun render(context: Context, snapshot: LearnerSnapshot): File {
        val width = 1700
        val height = 2400
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val bg = Paint().apply { shader = LinearGradient(0f, 0f, width.toFloat(), height.toFloat(), intArrayOf(Color.parseColor("#F8FAFC"), Color.parseColor("#EEF2FF"), Color.parseColor("#FAF5FF")), null, Shader.TileMode.CLAMP) }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)
        val title = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#111827"); textSize = 54f; typeface = Typeface.create(Typeface.DEFAULT_BOLD, Typeface.BOLD) }
        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0F172A"); textSize = 28f }
        val sub = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#475569"); textSize = 30f }

        canvas.drawText("گزارش مدرس | PharmaCoach AI", 80f, 95f, title)
        canvas.drawText("فراگیر: ${snapshot.learnerName}   |   سطح: ${snapshot.levelLabel}   |   امتیاز: ${snapshot.overallScore}٪", 80f, 145f, sub)
        drawPanel(canvas, 60f, 190f, 1580f, 300f, "خلاصه سریع", listOf(
            "نقاط قوت: ${snapshot.strengths.joinToString(" | ")}",
            "نقاط ضعف: ${snapshot.weaknesses.joinToString(" | ")}",
            "الگوهای خطا: ${snapshot.mistakePatterns.joinToString(" | ")}"
        ), body, title)

        var y = 540f
        canvas.drawText("نمودار مهارتی", 80f, y, title)
        y += 40f
        snapshot.domainScores.forEach {
            drawBar(canvas, 110f, y, 1250f, it.title, it.mastery, it.accuracy, body)
            y += 104f
        }

        drawPanel(canvas, 60f, 1500f, 1580f, 600f, "نسخه آموزشی پیشنهادی", snapshot.recommendations.ifEmpty { listOf("مرور هدفمند + تست ترکیبی + بازگشت به نقشه مفهومی") }, body, title)
        val out = File(context.cacheDir, "pharma_educator_report.png")
        FileOutputStream(out).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return out
    }

    private fun drawPanel(canvas: Canvas, x: Float, y: Float, w: Float, h: Float, heading: String, lines: List<String>, body: Paint, title: Paint) {
        val box = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; setShadowLayer(16f, 0f, 6f, Color.argb(26, 0, 0, 0)) }
        canvas.drawRoundRect(RectF(x, y, x + w, y + h), 30f, 30f, box)
        canvas.drawText(heading, x + 26f, y + 54f, title)
        var yy = y + 110f
        lines.forEach {
            canvas.drawText("• $it", x + 30f, yy, body)
            yy += 56f
        }
    }

    private fun drawBar(canvas: Canvas, x: Float, y: Float, width: Float, title: String, mastery: Int, accuracy: Int, paint: Paint) {
        val label = Paint(paint).apply { typeface = Typeface.create(Typeface.DEFAULT_BOLD, Typeface.BOLD) }
        canvas.drawText("$title  |  تسلط $mastery٪  |  دقت $accuracy٪", x, y, label)
        val track = Paint().apply { color = Color.parseColor("#E2E8F0") }
        val fill = Paint().apply { color = when { mastery >= 85 -> Color.parseColor("#10B981"); mastery >= 65 -> Color.parseColor("#3B82F6"); mastery >= 45 -> Color.parseColor("#F59E0B"); else -> Color.parseColor("#EF4444") } }
        val top = y + 16f
        canvas.drawRoundRect(RectF(x, top, x + width, top + 30f), 15f, 15f, track)
        canvas.drawRoundRect(RectF(x, top, x + (width * mastery / 100f), top + 30f), 15f, 15f, fill)
    }
}
