package com.openai.pharmacoach.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.openai.pharmacoach.PharmaViewModel

@Composable
fun HomeScreen(viewModel: PharmaViewModel, onOpenChapter: (String) -> Unit, onStartDiagnostic: () -> Unit) {
    val course = viewModel.course ?: return
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Box(Modifier.background(Brush.linearGradient(listOf(Color(0xFF0F172A), Color(0xFF4338CA), Color(0xFF0EA5E9), Color(0xFFF97316)))).padding(20.dp)) {
                    Column {
                        Text("PharmaCoach AI", style = MaterialTheme.typography.headlineSmall, color = Color.White, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("مدل اجرایی v12: سؤال‌پرس پویا، تدریس شخصی، دام آموزشی، ذخیره نکته و PDF حرفه‌ای برای EMT/Paramedic", color = Color.White)
                        Spacer(Modifier.height(12.dp))
                        AssistChip(onClick = { }, label = { Text("سطح فعلی: ${viewModel.levelLabel()}") })
                        Spacer(Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(onClick = onStartDiagnostic) { Text("شروع چالش هوشمند") }
                        }
                    }
                }
            }
        }
        item {
            ElevatedCard {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("۵ سطح یادگیری", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("مبتدی ← تازه‌کار ← رو‌به‌تسلط ← پیشرفته ← استاد")
                    Text("موتور v12 سؤال‌ها را کورکورانه زیاد نمی‌کند؛ با کمترین سؤال، بیشترین ضعف پنهان را استخراج و همان‌جا تدریس می‌کند.")
                }
            }
        }
        item { Text("فصل‌ها", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        items(course.chapters) { ch ->
            ElevatedCard(Modifier.fillMaxWidth().clickable { onOpenChapter(ch.id) }) {
                Column(Modifier.padding(16.dp)) {
                    Text(ch.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(ch.subtitle)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        AssistChip(onClick = { }, label = { Text("${ch.estimatedMinutes} دقیقه") })
                        AssistChip(onClick = { }, label = { Text("${ch.questions.size} تست") })
                        AssistChip(onClick = { }, label = { Text("${ch.sections.size} بخش") })
                    }
                }
            }
        }
    }
}
