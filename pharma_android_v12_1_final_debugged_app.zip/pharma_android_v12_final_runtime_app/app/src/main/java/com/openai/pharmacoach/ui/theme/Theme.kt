package com.openai.pharmacoach.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Light = lightColorScheme(
    primary = Color(0xFF4F46E5),
    secondary = Color(0xFF0891B2),
    tertiary = Color(0xFFF97316),
    background = Color(0xFFF8FAFC),
    surface = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE0E7FF),
    secondaryContainer = Color(0xFFCFFAFE),
    tertiaryContainer = Color(0xFFFFEDD5),
    errorContainer = Color(0xFFFEE2E2)
)

private val Dark = darkColorScheme(
    primary = Color(0xFFA5B4FC),
    secondary = Color(0xFF67E8F9),
    tertiary = Color(0xFFFDBA74),
    background = Color(0xFF020617),
    surface = Color(0xFF0F172A)
)

@Composable
fun PharmaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
}
