package com.openai.pharmacoach.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.openai.pharmacoach.PharmaViewModel

@Composable
fun AnalyticsScreen(viewModel: PharmaViewModel, onShareEducatorReport: () -> Unit, onExportEncrypted: () -> Unit, onShareSavedNotesPdf: () -> Unit) {
    val report = viewModel.snapshotText()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("هوش ماشینی تطبیقی", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("این بخش سطح ۵‌گانه، نقاط قوت و ضعف، الگوهای خطا و نسخه‌ی پیشنهادی برای مدرس را می‌سازد.")
        ElevatedCard { Text(report, modifier = Modifier.padding(16.dp)) }
        ElevatedCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("خروجی‌های هوشمند", fontWeight = FontWeight.Bold)
                Text("۱) تصویر گرافیکی مدرس")
                Button(onClick = onShareEducatorReport) { Text("ساخت گزارش گرافیکی مدرس") }
                Divider()
                Text("۲) فایل رمزنگاری‌شده توسعه‌دهنده")
                Text("برای نسخه‌های بعدی و تحلیل مهندسی، به‌صورت شفاف و با اقدام مستقیم کاربر ساخته می‌شود.")
                Button(onClick = onExportEncrypted) { Text("ساخت فایل رمزنگاری‌شده") }
                Divider()
                Text("۳) PDF نکات ذخیره‌شده")
                Text("تعداد نکات ذخیره‌شده: ${viewModel.savedNotes.size}")
                Button(onClick = onShareSavedNotesPdf, enabled = viewModel.savedNotes.isNotEmpty()) {
                    Text("ساخت PDF نکات منتخب")
                }
            }
        }
    }
}
